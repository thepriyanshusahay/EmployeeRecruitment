// JavaScript Document

document.viewform.edit1.onclick() = function () {
	document.getElementsByClassName('editinput').readonly = false;
	
  }
  



